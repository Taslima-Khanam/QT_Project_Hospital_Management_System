#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void adminfun();

    void doctorfun();

    void reciptionistfun();

    void backBtn();

    void loginfun();
protected:
    void showEvent(QShowEvent *event) override;
private:
    Ui::MainWindow *ui;
    QString currentrole;
    QStringList doctorUsernames;
     void loadDoctorUsernames();
    QStringList recipusername;

};
#endif // MAINWINDOW_H
